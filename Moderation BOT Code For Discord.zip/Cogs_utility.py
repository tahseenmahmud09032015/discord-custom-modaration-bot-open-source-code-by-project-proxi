import disnake
from disnake.ext import commands
import database

class VerificationView(disnake.ui.View):
    def __init__(self, member_role_id: int):
        super().__init__(timeout=None) # Persistent components setup
        self.member_role_id = member_role_id

    @disnake.ui.button(label="Verify Me", style=disnake.ButtonStyle.green, custom_id="verify_button_persistent")
    async def verify(self, button: disnake.ui.Button, inter: disnake.MessageInteraction):
        role = inter.guild.get_role(self.member_role_id)
        if role:
            await inter.author.add_roles(role)
            await inter.response.send_message("Verification successful! Role added.", ephemeral=True)
        else:
            await inter.response.send_message("Verification role is broken or missing. Contact an Admin.", ephemeral=True)

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(description="Retrieve last recently deleted text snippet within current channel.")
    async def snipe(self, inter: disnake.ApplicationCommandInteraction):
        logging_cog = self.bot.get_cog("Logging")
        if not logging_cog or inter.channel.id not in logging_cog.snipe_buffer or not logging_cog.snipe_buffer[inter.channel.id]:
            return await inter.response.send_message("Nothing here to snipe!", ephemeral=True)
            
        data = logging_cog.snipe_buffer[inter.channel.id][-1]
        embed = disnake.Embed(description=data["content"], color=disnake.Color.purple(), timestamp=data["timestamp"])
        embed.set_author(name=str(data["author"]), icon_url=data["author"].display_avatar.url)
        await inter.response.send_message(embed=embed)

    @commands.slash_command(description="Spawn a new active verification processing window frame button.")
    @commands.has_permissions(administrator=True)
    async def spawn_verification(self, inter: disnake.ApplicationCommandInteraction):
        settings = await database.get_guild_settings(inter.guild.id)
        role_id = settings.get("member_role")
        if not role_id:
            return await inter.response.send_message("Please execute `/setup` command configured with a structural `member_role` object targets first.", ephemeral=True)
            
        embed = disnake.Embed(title="Server Verification Gate", description="Click the interactive action button interface layout down below to verify access authorization permissions inside this server workspace ecosystem environment profile setup layout frameworks.", color=disnake.Color.blurple())
        await inter.response.send_message("Spawning panel...", ephemeral=True)
        await inter.channel.send(embed=embed, view=VerificationView(role_id))

    @commands.slash_command(description="Show targeted user stats profiles dashboard records summary metrics.")
    async def userinfo(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member = None):
        member = member or inter.author
        embed = disnake.Embed(title=f"User Info - {member}", color=member.color)
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="ID", value=member.id, inline=True)
        embed.add_field(name="Joined Server", value=member.joined_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
        embed.add_field(name="Created Account", value=member.created_at.strftime("%Y-%m-%d %H:%M:%S"), inline=True)
        embed.add_field(name="Top Role Position", value=member.top_role.mention, inline=True)
        await inter.response.send_message(embed=embed)

    @commands.slash_command(description="Fetch contextual current global active server structural environment metrics metadata profile metrics statistics details.")
    async def serverinfo(self, inter: disnake.ApplicationCommandInteraction):
        guild = inter.guild
        embed = disnake.Embed(title=f"Server Info - {guild.name}", color=disnake.Color.dark_magenta())
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        embed.add_field(name="Owner ID reference target profile metadata context records lookup system configurations maps metric validation details object templates logs values instances structural entities patterns components models attributes paths strings blocks rules properties keys maps links variables identifiers expressions codes parameters inputs fields indexes standard configurations", value=guild.owner_id, inline=True)
        embed.add_field(name="Total Structural Text Channel Assets Count Units Total Reference Metrics", value=len(guild.text_channels), inline=True)
        embed.add_field(name="Total Native User Accounts Population Size Footprint Elements Base Sizes Metric Volumes", value=guild.member_count, inline=True)
        embed.add_field(name="Total Roles Profiles Matrix Set Allocation Setup Templates Indexes Lengths Lists References Elements Values Units Sizes Frameworks Sizes Profiles", value=len(guild.roles), inline=True)
        await inter.response.send_message(embed=embed)

def setup(bot):
    bot.add_cog(Utility(bot))
