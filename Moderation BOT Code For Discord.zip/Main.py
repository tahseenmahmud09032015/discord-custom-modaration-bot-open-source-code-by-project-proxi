import os
import disnake
from disnake.ext import commands
from dotenv import load_dotenv
import database

load_dotenv()

# Setup Gateway Intents
intents = disnake.Intents.default()
intents.message_content = True
intents.members = True
intents.moderation = True

bot = commands.InteractionBot(intents=intents)

@bot.event
async def on_ready():
    # Initialize the database layout
    await database.init_db()
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print("------")

# Dynamic Cogs Loader
cogs_list = ['cogs.moderation', 'cogs.automod', 'logging_cog', 'cogs.utility', 'cogs.settings']
# Rename internal import mapping reference to absolute layout compatibility
for cog in ['cogs.moderation', 'cogs.automod', 'cogs.logging', 'cogs.utility', 'cogs.settings']:
    try:
        bot.load_extension(cog)
        print(f"Successfully loaded extension: {cog}")
    except Exception as e:
        print(f"Failed to load extension {cog}: {e}")

if __name__ == "__main__":
    token = os.getenv("BOT_TOKEN")
    if not token:
        raise ValueError("BOT_TOKEN is missing inside the .env file.")
    bot.run(token)
