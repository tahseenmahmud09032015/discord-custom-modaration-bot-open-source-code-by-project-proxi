import disnake
from disnake.ext import commands, tasks
import database
import datetime
from datetime import timedelta

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_temp_punishments.start()

    def cog_unload(self):
        self.check_temp_punishments.cancel()

    async def check_mod_perms(self, inter: disnake.ApplicationCommandInteraction) -> bool:
        """Helper checking standard Moderation roles config or native context permissions."""
        settings = await database.get_guild_settings(inter.guild.id)
        mod_role_id = settings.get("mod_role")
        if mod_role_id and inter.guild.get_role(mod_role_id) in inter.author.roles:
            return True
        return inter.author.guild_permissions.kick_members

    async def apply_escalation(self, inter: disnake.ApplicationCommandInteraction, target: disnake.Member):
        """Processes auto-escalation matrix thresholds."""
        infractions = await database.get_infractions(inter.guild.id, target.id)
        warn_count = sum(1 for inf in infractions if inf[4] == 'warn')

        if warn_count >= 5:
            await inter.guild.ban(target, reason="Auto-escalation: 5 Warn Threshold Met")
            await database.add_infraction(inter.guild.id, target.id, self.bot.user.id, "ban", "Auto-escalation: 5 Warns reached", 0)
            await inter.channel.send(f"**{target}** has been automatically banned (5 warnings reached).")
        elif warn_count >= 3:
            duration = 3600 # 1 hour
            await target.timeout(until=disnake.utils.utcnow() + timedelta(seconds=duration), reason="Auto-escalation: 3 Warn Threshold Met")
            await database.add_infraction(inter.guild.id, target.id, self.bot.user.id, "timeout", "Auto-escalation: 3 Warns reached", 0, duration)
            await inter.channel.send(f"**{target}** has been automatically timed out for 1 hour (3 warnings reached).")

    @commands.slash_command(description="Warn a user.")
    async def warn(self, inter: disnake.ApplicationCommandInteraction, user: disnake.Member, reason: str):
        if not await self.check_mod_perms(inter):
            return await inter.response.send_message("Missing Permissions.", ephemeral=True)
        
        await database.add_infraction(inter.guild.id, user.id, inter.author.id, "warn", reason, 1)
        await inter.response.send_message(f"Warned {user.mention} for: {reason}", ephemeral=True)
        await self.apply_escalation(inter, user)

    @commands.slash_command(description="Timeout a member dynamically.")
    async def timeout(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, duration_minutes: int, reason: str):
        if not await self.check_mod_perms(inter):
            return await inter.response.send_message("Missing Permissions.", ephemeral=True)
        
        until_time = disnake.utils.utcnow() + timedelta(minutes=duration_minutes)
        await member.timeout(until=until_time, reason=reason)
        await database.add_infraction(inter.guild.id, member.id, inter.author.id, "timeout", reason, 0, duration_minutes * 60)
        await inter.response.send_message(f"Timed out {member.mention} for {duration_minutes} minutes.", ephemeral=True)

    @commands.slash_command(description="Kick a member.")
    async def kick(self, inter: disnake.ApplicationCommandInteraction, member: disnake.Member, reason: str):
        if not await self.check_mod_perms(inter):
            return await inter.response.send_message("Missing Permissions.", ephemeral=True)
        await member.kick(reason=reason)
        await database.add_infraction(inter.guild.id, member.id, inter.author.id, "kick", reason, 0)
        await inter.response.send_message(f"Kicked {member.mention}.", ephemeral=True)

    @commands.slash_command(description="Ban a user.")
    async def ban(self, inter: disnake.ApplicationCommandInteraction, user: disnake.User, reason: str, duration_hours: int = None):
        if not await self.check_mod_perms(inter):
            return await inter.response.send_message("Missing Permissions.", ephemeral=True)
        
        duration_sec = duration_hours * 3600 if duration_hours else None
        await inter.guild.ban(user, reason=reason)
        await database.add_infraction(inter.guild.id, user.id, inter.author.id, "ban", reason, 0, duration_sec)
        await inter.response.send_message(f"Banned {user.mention}.", ephemeral=True)

    @commands.slash_command(description="Unban a user.")
    async def unban(self, inter: disnake.ApplicationCommandInteraction, user_id: str, reason: str):
        if not await self.check_mod_perms(inter):
            return await inter.response.send_message("Missing Permissions.", ephemeral=True)
        user = await self.bot.get_or_fetch_user(int(user_id))
        await inter.guild.unban(user, reason=reason)
        await inter.response.send_message(f"Unbanned reference {user_id}.", ephemeral=True)

    @commands.slash_command(description="Purge a specific number of channel messages.")
    async def clear(self, inter: disnake.ApplicationCommandInteraction, amount: int):
        if not await self.check_mod_perms(inter):
            return await inter.response.send_message("Missing Permissions.", ephemeral=True)
        await inter.channel.purge(limit=amount)
        await inter.response.send_message(f"Cleared {amount} messages.", ephemeral=True)

    @tasks.loop(seconds=30)
    async def check_temp_punishments(self):
        """Scans database context to expire active temp-bans & active internal target actions."""
        active_infractions = await database.get_active_temp_punishments()
        now = datetime.datetime.utcnow()
        
        for inf in active_infractions:
            inf_id, guild_id, user_id, mod_id, inf_type, reason, points, timestamp_str, duration, active = inf
            timestamp = datetime.datetime.fromisoformat(timestamp_str)
            expiry_time = timestamp + timedelta(seconds=duration)
            
            if now >= expiry_time:
                guild = self.bot.get_guild(guild_id)
                if not guild:
                    continue
                
                try:
                    if inf_type == "ban":
                        user = await self.bot.get_or_fetch_user(user_id)
                        await guild.unban(user, reason="Temp-ban expired")
                except Exception:
                    pass
                
                await database.deactivate_infraction(inf_id)

    @check_temp_punishments.before_loop
    async def before_check_temp_punishments(self):
        await self.bot.wait_until_ready()

def setup(bot):
    bot.add_cog(Moderation(bot))
