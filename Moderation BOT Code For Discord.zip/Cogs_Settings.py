import disnake
from disnake.ext import commands
import database

class Settings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.slash_command(description="Configure bot properties per server.")
    @commands.has_permissions(administrator=True)
    async def setup(
        self, 
        inter: disnake.ApplicationCommandInteraction, 
        mod_log_channel: disnake.TextChannel = None,
        mute_role: disnake.Role = None,
        mod_role: disnake.Role = None,
        member_role: disnake.Role = None
    ):
        await inter.response.defer(ephemeral=True)
        guild_id = inter.guild.id

        if mod_log_channel:
            await database.set_guild_setting(guild_id, "mod_log", mod_log_channel.id)
        if mute_role:
            await database.set_guild_setting(guild_id, "mute_role", mute_role.id)
        if mod_role:
            await database.set_guild_setting(guild_id, "mod_role", mod_role.id)
        if member_role:
            await database.set_guild_setting(guild_id, "member_role", member_role.id)

        await inter.edit_original_message(content="Guild settings updated successfully.")

def setup(bot):
    bot.add_cog(Settings(bot))
