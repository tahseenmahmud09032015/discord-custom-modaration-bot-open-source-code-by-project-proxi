import disnake
from disnake.ext import commands
import database
from collections import defaultdict

class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Snipe buffer caching channel maps: {channel_id: [list of deleted messages]}
        self.snipe_buffer = defaultdict(list)

    async def send_log(self, guild: disnake.Guild, embed: disnake.Embed):
        settings = await database.get_guild_settings(guild.id)
        log_channel_id = settings.get("mod_log")
        if log_channel_id:
            channel = guild.get_channel(log_channel_id)
            if channel:
                await channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_message_delete(self, message: disnake.Message):
        if message.author.bot or not message.guild:
            return
        
        # Save payload details inside dynamic local runtime cache for the /snipe utility command
        self.snipe_buffer[message.channel.id].append({
            "content": message.content,
            "author": message.author,
            "timestamp": message.created_at
        })
        if len(self.snipe_buffer[message.channel.id]) > 100:
            self.snipe_buffer[message.channel.id].pop(0)

        embed = disnake.Embed(title="Message Deleted", color=disnake.Color.orange(), description=f"**Author:** {message.author.mention}\n**Channel:** {message.channel.mention}")
        embed.add_field(name="Content", value=message.content or "[No text content found]", inline=False)
        await self.send_log(message.guild, embed)

    @commands.Cog.listener()
    async def on_message_edit(self, before: disnake.Message, after: disnake.Message):
        if before.author.bot or before.content == after.content:
            return
        embed = disnake.Embed(title="Message Edited", color=disnake.Color.blue(), description=f"**Author:** {before.author.mention}\n**Channel:** {before.channel.mention}")
        embed.add_field(name="Before", value=before.content or "[Empty content fields]", inline=False)
        embed.add_field(name="After", value=after.content or "[Empty content fields]", inline=False)
        await self.send_log(before.guild, embed)

    @commands.Cog.listener()
    async def on_guild_channel_create(self, channel: disnake.abc.GuildChannel):
        embed = disnake.Embed(title="Channel Created", color=disnake.Color.green(), description=f"**Name:** {channel.name}\n**Type:** {channel.type}")
        await self.send_log(channel.guild, embed)

    @commands.Cog.listener()
    async def on_guild_channel_delete(self, channel: disnake.abc.GuildChannel):
        embed = disnake.Embed(title="Channel Deleted", color=disnake.Color.red(), description=f"**Name:** {channel.name}")
        await self.send_log(channel.guild, embed)

def setup(bot):
    bot.add_cog(Logging(bot))
