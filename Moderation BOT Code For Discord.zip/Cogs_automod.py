import disnake
from disnake.ext import commands
import time
import re
import database

class AutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.join_tracker = {}  # Tracks timestamps for anti-raid metrics: {guild_id: [timestamps]}
        self.cooldown_tracker = {} # Tracks dynamic spam: {user_id: last_action_timestamp}

    async def log_automod_violation(self, message: disnake.Message, reason: str):
        """Helper function to log violations directly to configured mod-log channels."""
        settings = await database.get_guild_settings(message.guild.id)
        log_channel_id = settings.get("mod_log")
        if log_channel_id:
            channel = message.guild.get_channel(log_channel_id)
            if channel:
                embed = disnake.Embed(title="AutoMod Violation Triggered", color=disnake.Color.red())
                embed.add_field(name="User", value=f"{message.author.mention} ({message.author.id})", inline=False)
                embed.add_field(name="Reason", value=reason, inline=False)
                embed.add_field(name="Content Snippet", value=message.content[:500], inline=False)
                await channel.send(embed=embed)

    @commands.Cog.listener()
    async def on_member_join(self, member: disnake.Member):
        """Anti-raid integration logic handling joint-burst thresholds."""
        guild_id = member.guild.id
        now = time.time()
        
        if guild_id not in self.join_tracker:
            self.join_tracker[guild_id] = []
            
        self.join_tracker[guild_id] = [t for t in self.join_tracker[guild_id] if now - t < 10]
        self.join_tracker[guild_id].append(now)
        
        if len(self.join_tracker[guild_id]) > 5:
            # Panic action: Pause invites or enable strict verification metrics if configured
            settings = await database.get_guild_settings(guild_id)
            log_channel_id = settings.get("mod_log")
            if log_channel_id:
                channel = member.guild.get_channel(log_channel_id)
                if channel:
                    await channel.send("⚠️ **Anti-Raid Warning Triggered!** More than 5 joins recorded within 10 seconds.")

    @commands.Cog.listener()
    async def on_message(self, message: disnake.Message):
        if message.author.bot or not message.guild:
            return

        # Basic configurations checks
        settings = await database.get_guild_settings(message.guild.id)
        bad_words = settings.get("bad_words", ["invite-spam-match", "badword1"])
        
        # 1. Check Invites and General Explicit Links
        if "discord.gg/" in message.content.lower():
            await message.delete()
            await database.add_infraction(message.guild.id, message.author.id, self.bot.user.id, "warn", "AutoMod: Posted Discord Invite", 1)
            await self.log_automod_violation(message, "Posted Discord Invite Links")
            return

        # 2. Caps Filter
        if len(message.content) > 10:
            caps_ratio = sum(1 for c in message.content if c.isupper()) / len(message.content)
            if caps_ratio > 0.70:
                await message.delete()
                await self.log_automod_violation(message, "Excessive Capitalization (>70%)")
                return

        # 3. Mass Mention Filter (>5)
        if len(message.mentions) > 5:
            await message.delete()
            await database.add_infraction(message.guild.id, message.author.id, self.bot.user.id, "warn", "AutoMod: Mass Mentions", 1)
            await self.log_automod_violation(message, "Mass Mentions (>5 Users)")
            return

        # 4. Bad Words Filter Check
        if any(word in message.content.lower() for word in bad_words):
            await message.delete()
            await self.log_automod_violation(message, "Contains Forbidden Banned Word Phrases")
            return

def setup(bot):
    bot.add_cog(AutoMod(bot))
