import aiosqlite
import json
from datetime import datetime

DB_NAME = "bot_database.db"

async def init_db():
    """Initializes the SQLite database tables."""
    async with aiosqlite.connect(DB_NAME) as db:
        # Infractions table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS infractions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER,
                user_id INTEGER,
                mod_id INTEGER,
                type TEXT,
                reason TEXT,
                points INTEGER,
                timestamp TEXT,
                duration INTEGER,
                active INTEGER DEFAULT 1
            )
        """)
        # Guild configuration table
        await db.execute("""
            CREATE TABLE IF NOT EXISTS guild_settings (
                guild_id INTEGER PRIMARY KEY,
                settings TEXT
            )
        """)
        await db.commit()

async def add_infraction(guild_id: int, user_id: int, mod_id: int, inf_type: str, reason: str, points: int, duration: int = None):
    """Adds a new infraction record to the database."""
    async with aiosqlite.connect(DB_NAME) as db:
        timestamp = datetime.utcnow().isoformat()
        await db.execute(
            "INSERT INTO infractions (guild_id, user_id, mod_id, type, reason, points, timestamp, duration) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (guild_id, user_id, mod_id, inf_type, reason, points, timestamp, duration)
        )
        await db.commit()

async def get_infractions(guild_id: int, user_id: int):
    """Retrieves all active infractions for a user."""
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT * FROM infractions WHERE guild_id = ? AND user_id = ? AND active = 1", (guild_id, user_id)) as cursor:
            return await cursor.fetchall()

async def get_active_temp_punishments():
    """Retrieves all active temporary bans and mutes."""
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT * FROM infractions WHERE (type = 'mute' OR type = 'ban') AND duration IS NOT NULL AND active = 1") as cursor:
            return await cursor.fetchall()

async def deactivate_infraction(inf_id: int):
    """Marks a temporary infraction as inactive."""
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE infractions SET active = 0 WHERE id = ?", (inf_id,))
        await db.commit()

async def get_guild_settings(guild_id: int) -> dict:
    """Fetches the configuration dictionary for a guild."""
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT settings FROM guild_settings WHERE guild_id = ?", (guild_id,)) as cursor:
            row = await cursor.fetchone()
            if row:
                return json.loads(row[0])
            return {}

async def set_guild_setting(guild_id: int, key: str, value):
    """Updates a single key in the guild's configuration JSON."""
    async with aiosqlite.connect(DB_NAME) as db:
        settings = await get_guild_settings(guild_id)
        settings[key] = value
        settings_str = json.dumps(settings)
        await db.execute(
            "INSERT INTO guild_settings (guild_id, settings) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET settings = ?",
            (guild_id, settings_str, settings_str)
        )
        await db.commit()


